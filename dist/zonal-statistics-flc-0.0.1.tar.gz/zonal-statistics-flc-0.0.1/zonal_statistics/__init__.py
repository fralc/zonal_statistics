name = "zonal_statistics"
from zonal_statistics.zonal_functions import zonal_vector, zonal_raster
from zonal_statistics.geohash import vector_to_geohash, raster_to_geohash
